﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Sport.API.Entities
{
    public class Activity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; }

        [Required]
        public DateTime Beginning { get; set; }

        [Required]
        public DateTime Ending { get; set; }

        [Required]
        public string TrainerId { get; set; }

        public ICollection<ClientActivity> ClientActivities { get; set; }
        = new List<ClientActivity>();
    }
}
